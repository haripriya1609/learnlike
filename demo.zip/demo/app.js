let editId = null;

// CREATE
function addTask() {
    let input = document.getElementById("taskInput");
    let taskText = input.value.trim();

    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    if (editId === null) {
        createTask(taskText);
    } else {
        updateTask(taskText);
    }

    input.value = "";
}

function createTask(taskText) {
    let ul = document.getElementById("taskList");

    let li = document.createElement("li");
    let id = Date.now();
    li.setAttribute("data-id", id);

    li.innerHTML = `
        <span class="task-text">${taskText}</span>
        <div class="btns">
            <span class="edit-btn" onclick="editTask(${id})">✎</span>
            <span class="delete-btn" onclick="deleteTask(${id})">✖</span>
        </div>
    `;

    ul.appendChild(li);
}

// READ (Auto — we display tasks live)


// UPDATE
function editTask(id) {
    let li = document.querySelector(`li[data-id="${id}"]`);
    let text = li.querySelector(".task-text").innerText;

    document.getElementById("taskInput").value = text;
    document.getElementById("addBtn").innerText = "Update";

    editId = id;
}

function updateTask(newText) {
    let li = document.querySelector(`li[data-id="${editId}"]`);
    li.querySelector(".task-text").innerText = newText;

    document.getElementById("addBtn").innerText = "Add";
    editId = null;
}


// DELETE
function deleteTask(id) {
    let li = document.querySelector(`li[data-id="${id}"]`);
    li.remove();
}
